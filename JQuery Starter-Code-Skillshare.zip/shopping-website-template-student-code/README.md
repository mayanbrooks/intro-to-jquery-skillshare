# shopping-website-template
A website template that can be used to host merchandise like clothing, art, and other creative products or even advertise photos. 

Built by: Maya Brooks

Built With: Materialize CSS, JQuery, Iconfinder.

Photos show on the site are not licensed and not under a CCO. They are pulled from the ASOS clothing website during a standard google image search for display purposes only. They are not for commercial use. This is not a live site on the web. 
