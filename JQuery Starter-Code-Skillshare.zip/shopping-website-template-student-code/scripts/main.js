// WELCOME! YOUR JQUERY GOES HERE!


// Goal: popup Loads as soon as the page loads. Make popup disappear upon user click



// Goal: Make hamburger menu nav appear and disappear based on user click




// Goal: Change color of subscribe button to indicate user interactivity. Change text in button to let user know when "subscription" works.
